package jagmag.employee;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import javax.transaction.Transactional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RestController;

import jagmag.common.ResponseJson;
import jagmag.exceptions.GenericException;
import jagmag.exceptions.ProcessException;
import jagmag.util.AppUtils;
import jagmag.util.Constants;

@RestController
@Transactional(rollbackOn = { ProcessException.class, GenericException.class })
public class EmployeeControllerImpl implements EmployeeController{
	private final Logger log = LoggerFactory.getLogger(this.getClass());

	EmployeeControllerImpl() {
		log.info("Enter in the ControllerImpl");
	}
	@Autowired
	EmployeeService employeeService;
	
	@Override
	public ResponseJson<Employee> saveEmployee(Employee employee) {
		try {
			if(employee==null) {
				log.info("Request is  empty.");
				return new ResponseJson<>(HttpStatus.BAD_REQUEST, "Request is  empty.", null);
			}
employee.setId(UUID.randomUUID().toString());
employee.setStatus(Constants.STATUS_ACTIVE); 
			return new ResponseJson<>(HttpStatus.OK, "Data saved successfully.", employeeService.saveOrUpdateEmployee(employee));
		}catch (GenericException e) {
			e.printStackTrace();
			log.error("There is an error to save employee." + e.getMessage());
			return new ResponseJson<>(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage(), null);
		}catch (Exception e) {
			e.printStackTrace();
			log.error("There is an error to save employee." + e.getMessage());
			return new ResponseJson<>(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage(), null);
		}		
	}

	@Override
	public ResponseJson<Employee> updateEmployee(Employee employee) {
		try {
			if((employee==null)||(employee!=null && (AppUtils.isNotEmpty(employee.getId()) || (AppUtils.isNotEmpty(employee.getEmailId()))))) {
				log.info("Request is  empty.");
				return new ResponseJson<>(HttpStatus.BAD_REQUEST, "Request is  empty.", null);
			}
		Employee employeeDetail= employeeService.getEmployeeByIdOrEmail(employee.getId(), employee.getEmailId());
		if(employeeDetail==null) {
			return new ResponseJson<>(HttpStatus.NOT_FOUND, "No active employee is found either by id:"+ employee.getId() +" or email:" + employee.getEmailId(), employeeDetail);
		}
		if(AppUtils.isNotEmpty(employee.getAge())) {
			employeeDetail.setAge(employee.getAge());
		}
		if(AppUtils.isNotEmpty(employee.getFirstName())) {
			employeeDetail.setFirstName(employee.getFirstName());
		}
		if(AppUtils.isNotEmpty(employee.getLastName())) {
			employeeDetail.setLastName(employee.getLastName());
		}
		if(AppUtils.isNotEmpty(employee.getGender())) {
			employeeDetail.setGender(employee.getGender());
		}
		if(AppUtils.isNotEmpty(employee.getEmailId())) {
			employeeDetail.setEmailId(employee.getEmailId());
		}
		return new ResponseJson<>(HttpStatus.OK, "Data updated successfully.", employeeService.saveOrUpdateEmployee(employeeDetail));
		}catch (GenericException e) {
			e.printStackTrace();
			log.error("There is an error to updated employee." + e.getMessage());
			return new ResponseJson<>(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage(), null);
		}catch (Exception e) {
			e.printStackTrace();
			log.error("There is an error to updated employee." + e.getMessage());
			return new ResponseJson<>(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage(), null);
		}		
	}

	@Override
	public ResponseJson<List<Employee>> getEmployee(Employee employee) {
		try {
			List<Employee> employeeList=null;
			if((employee==null)) {
				employeeList=employeeService.getEmployee(employee);
			}else if(AppUtils.isNotEmpty(employee.getId()) || AppUtils.isNotEmpty(employee.getEmailId())){
				employeeList= new ArrayList<>();
				Employee employeeDetail= employeeService.getEmployeeByIdOrEmail(employee.getId(), employee.getEmailId());
				employeeList.add(employeeDetail);
			}
			return new ResponseJson<>(HttpStatus.OK, "Employee data list are: ", employeeList);
		}catch (GenericException e) {
			e.printStackTrace();
			log.error("There is an error to soft delete." + e.getMessage());
			return new ResponseJson<>(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage(), null);
		}catch (Exception e) {
			e.printStackTrace();
			log.error("There is an error to soft  delete." + e.getMessage());
			return new ResponseJson<>(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage(), null);
		}
	}

	@Override
	public ResponseJson<Employee> deleteEmployee(Employee employee) {
		try {
			if((employee==null)||(employee!=null && (AppUtils.isNotEmpty(employee.getId()) || (AppUtils.isNotEmpty(employee.getEmailId()))))) {
				log.info("Request is  empty.");
				return new ResponseJson<>(HttpStatus.BAD_REQUEST, "Request is  empty.", null);
			}
		Employee employeeDetail= employeeService.getEmployeeByIdOrEmail(employee.getId(), employee.getEmailId());
		if(employeeDetail==null) {
			return new ResponseJson<>(HttpStatus.NOT_FOUND, "No active employee is found either by id:"+ employee.getId() +" or email:" + employee.getEmailId(), employeeDetail);
		}
		employeeDetail.setStatus(Constants.STATUS_INACTIVE);
		return new ResponseJson<>(HttpStatus.OK, "Data deleted successfully.", employeeService.saveOrUpdateEmployee(employeeDetail));
		}catch (GenericException e) {
			e.printStackTrace();
			log.error("There is an error to soft delete." + e.getMessage());
			return new ResponseJson<>(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage(), null);
		}catch (Exception e) {
			e.printStackTrace();
			log.error("There is an error to soft  delete." + e.getMessage());
			return new ResponseJson<>(HttpStatus.INTERNAL_SERVER_ERROR, e.getMessage(), null);
		}		
	}


}
