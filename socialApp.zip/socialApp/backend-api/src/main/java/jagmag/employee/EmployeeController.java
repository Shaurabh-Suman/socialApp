package jagmag.employee;

import java.util.List;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import jagmag.common.ResponseJson;

@RestController
@CrossOrigin(origins = "*")
@RequestMapping("/api/v1/employee")
public interface EmployeeController {
	@PostMapping("/save")
	ResponseJson<Employee> saveEmployee(@RequestBody(required =true) Employee employee);
	
	@PostMapping("/update")
	ResponseJson<Employee> updateEmployee(@RequestBody(required =true) Employee employee);

	//:: In body is empty then will get whole employee list otherWise fetching the particular data based on id/email
	@PostMapping("/getEmployee")
	ResponseJson<List<Employee>> getEmployee(@RequestBody(required =true) Employee employee);
	
	//:: Soft delete
	@PostMapping("/delete")
	ResponseJson<Employee> deleteEmployee(@RequestBody(required =true) Employee employee);


}
