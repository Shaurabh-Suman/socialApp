package jagmag.employee;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import jagmag.exceptions.GenericException;

@Component
public class EmployeeServiceImpl implements EmployeeService {
	private final Logger log = LoggerFactory.getLogger(this.getClass());

	EmployeeServiceImpl() {
		log.info("Enter in the ServiceImpl");
	}

	@Autowired
	private EmployeeRepository employeeRepository;

	@Override
	public Employee saveOrUpdateEmployee(Employee employee) throws GenericException {
		try {
			return employeeRepository.save(employee);
		} catch (Exception excep) {
			throw new GenericException(excep);
		}
	}

	@Override
	public List<Employee> getEmployee(Employee employee) throws GenericException {
		try {
			return employeeRepository.findAll();
		} catch (Exception excep) {
			throw new GenericException(excep);
		}
	}

	@Override
	public Employee getEmployeeByIdOrEmail(String id, String email) throws GenericException {
		try {
			return employeeRepository.findByIdOrEmail(id, email);
		} catch (Exception excep) {
			throw new GenericException(excep);
		}

	}
}
