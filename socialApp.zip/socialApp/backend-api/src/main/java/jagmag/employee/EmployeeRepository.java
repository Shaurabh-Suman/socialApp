package jagmag.employee;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

@Repository
public interface EmployeeRepository extends JpaRepository<Employee, String>, JpaSpecificationExecutor<Employee>{	
	@Query(value ="SELECT p.* FROM employee e WHERE  e.status='ACTIVE'  AND (e.id = :id  or e.email=:email )", nativeQuery = true)
	Employee findByIdOrEmail(String id, String email);

}
