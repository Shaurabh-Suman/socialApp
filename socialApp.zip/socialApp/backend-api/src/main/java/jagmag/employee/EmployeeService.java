package jagmag.employee;

import java.util.List;

import org.springframework.stereotype.Service;

import jagmag.exceptions.GenericException;

@Service
public interface EmployeeService {
	Employee saveOrUpdateEmployee(Employee employee) throws GenericException;

	List<Employee> getEmployee(Employee employee) throws GenericException;

	Employee getEmployeeByIdOrEmail(String id, String email) throws GenericException;
}
