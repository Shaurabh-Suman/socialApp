package jagmag.common;

import java.io.Serializable;

import org.springframework.http.HttpStatus;

public class ResponseJson<T> implements Serializable {

    private static final long serialVersionUID = -3942144430594863526L;

    private HttpStatus status;
    private int code;
    private String message;
    private long syncTime;
    private T data;
    private String lastSyncTime;
    private String role;
    

    /*
     * @Expose private int noOfNotifications;
     */

    public ResponseJson() {
        // TODO Auto-generated constructor stub
    }

    /*
     * public ResponseJson(String status, String message, int noOfNotifications)
     * { super(); this.status = status; this.message = message;
     * this.noOfNotifications = noOfNotifications; }
     */
    
    

    
    public ResponseJson(HttpStatus status, String message, T data) {
        super();
        this.status = status;
        this.message = message;
        this.data = data;
    }

    public ResponseJson(HttpStatus status, String message, T data, long syncTime) {
        super();
        this.status = status;
        this.message = message;
        this.data = data;
        this.syncTime = syncTime;
    }

    public ResponseJson(HttpStatus status, String message) {
        super();
        this.status = status;
        this.message = message;
    }

    public ResponseJson(HttpStatus status, String message, T data, String lastSyncTime) {
        super();
        this.status = status;
        this.message = message;
        this.data = data;
        this.lastSyncTime = lastSyncTime;
    }

    public ResponseJson(HttpStatus status, String message, String lastSyncTime) {
        super();
        this.status = status;
        this.message = message;
        this.lastSyncTime = lastSyncTime;
    }

    public HttpStatus getStatus() {
        return status;
    }

    public void setStatus(HttpStatus status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }

    public long getSyncTime() {
        return syncTime;
    }

    public void setSyncTime(long syncTime) {
        this.syncTime = syncTime;
    }

    public String getLastSyncTime() {
        return lastSyncTime;
    }

    public void setLastSyncTime(String lastSyncTime) {
        this.lastSyncTime = lastSyncTime;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public int getCode() {
        return this.code;
    }

    public void setCode(int code) {
      this.code=code;
    }
    
    

	@Override
    public String toString() {
        return "ResponseJson{" +
                "status='" + status + '\'' +
                ", message='" + message + '\'' +
                ", syncTime=" + syncTime +
                ", data=" + data +
                ", lastSyncTime='" + lastSyncTime + '\'' +
                ", role='" + role + '\'' +
                '}';
    }
}