package jagmag.config;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

@Configuration
public class WebConfig implements WebMvcConfigurer{
	@Override
	public void addInterceptors(InterceptorRegistry registry) {
      // define the url patterns to intercept
		List<String> urlPatterns = new ArrayList<>();
		urlPatterns.add("/api/v1/**");

		String[] inputs = new String[urlPatterns.size()];
		int counter = 0;
		for (String str : urlPatterns) {
			inputs[counter++] = str;
		}
	}

}
