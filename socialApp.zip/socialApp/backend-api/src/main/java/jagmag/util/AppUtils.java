package jagmag.util;

public class AppUtils {

	public static final String SEPARATOR = ",";

	public static boolean isNotEmpty(String value) {
		if (value != null && !"".equals(value) && value != "NULL" && !"null".equals(value)) {
			return true;
		}
		return false;
	}

	}
