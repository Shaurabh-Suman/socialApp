package jagmag.util;

public class Constants {
	public static final String STATUS_INACTIVE = "INACTIVE";	
     public static final String STATUS_ACTIVE = "ACTIVE";
	
}
