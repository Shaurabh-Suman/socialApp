package jagmag.exceptions;

/**
 * @author SS
 */

public final class ProcessException extends Exception {

	private static final long serialVersionUID = 1L;

	private String message;
	private int code;
	private transient Object data;
	
	public ProcessException() {
		super();
	}

	public ProcessException(int code, String message) {
		super(message);
		this.code = code;
		this.message = message;
	}
	
	public ProcessException(int code, String message, Object data) {
		super(message);
		this.code = code;
		this.message = message;
		this.data = data;
	}


	public ProcessException(String message) {
		super(message);
		this.message = message;
	}
	
	public ProcessException(String message, Object data) {
		super(message);
		this.message = message;
		this.data = data;
	}
	
	public ProcessException(String message, Throwable cause) {
		super(cause);
		this.message = message;
	}
	
	public ProcessException(String message, Throwable cause, Object data) {
		super(cause);
		this.message = message;
		this.data = data;
	}
	
	public ProcessException(int code, String message, Throwable cause) {
		super(cause);
		this.code = code;
		this.message = message;
	}
	
	public ProcessException(int code, String message, Throwable cause, Object data) {
		super(cause);
		this.code = code;
		this.message = message;
		this.data = data;
	}

	public ProcessException(Throwable cause) {
		super(cause);
	}
	
	public int getCode() {
		return code;
	}

	public void setCode(int code) {
		this.code = code;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	@Override
	public String toString() {
		return message;
	}

	@Override
	public String getMessage() {
		return message;
	}

	public Object getData() {
		return data;
	}

	public void setData(Object data) {
		this.data = data;
	}
	
}
