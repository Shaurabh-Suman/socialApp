package jagmag.exceptions;

/**
 * @author SS
 */

public class GenericException extends Exception {

	private static final long serialVersionUID = 1L;

	private String message;
	private int code;
	
	public GenericException() {
		super();
	}

	public GenericException(int code, String message) {
		super(message);
		this.code = code;
		this.message = message;
	}


	public GenericException(String message) {
		super(message);
		this.message = message;
	}
	
	public GenericException(String message, Throwable cause) {
		super(cause);
		this.message = message;
	}
	
	public GenericException(int code, String message, Throwable cause) {
		super(cause);
		this.code = code;
		this.message = message;
	}

	public GenericException(Throwable cause) {
		super(cause);
	}
	
	public int getCode() {
		return code;
	}

	public void setCode(int code) {
		this.code = code;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	@Override
	public String toString() {
		return message;
	}

	@Override
	public String getMessage() {
		return message;
	}

}
